"""
Configuration file for storing personal information used in job applications.
Edit this file with your actual information.
"""

# Personal Information
PERSONAL_INFO = {
    "first_name": "Gavin",
    "last_name": "Bennett",
    "email": "gavin.bennett5@outlook.com",
    "phone": "3145849418",
    "address": "937 Little Fieldstone Court",
    "city": "Wentzville",
    "state": "Missouri",
    "zip_code": "63385",
    "country": "United States of America",
    "linkedin": "www.linkedin.com/in/gavin-bennett-908a2378",
    "github": "https://github.com/trickortreat50"
}

# Education Information (can have multiple degrees)
EDUCATION = [
    {
        "degree": "Bachelors",
        "field_of_study": "Geology",
        "university": "Missouri State University",
        "graduation_year": "2016",
        "gpa": "3.00",
        "is_highest": true
    }
]

# Work Experience (most recent first)
WORK_EXPERIENCE = [
    {
        "company": "Stifel Financial Corp.",
        "position": "Security Engineer",
        "start_date": "01/2024",
        "end_date": "Present",
        "description": "\u2022\tStrengthened security posture by proactively diagnosing and resolving critical technical issues, including blocked firewall traffic, application connectivity failures, DNS errors, and certificate-related concerns -- ensuring uninterrupted business operations"
    }
]

# Skills
SKILLS = [
    "\u2022\tLed firewall vulnerability mitigation by upgrading code on internet-face and B2B firewalls",
    "protecting the organization against emerging CVEs and improving overall cyber resilience"
]

# Common Application Questions and Answers
COMMON_ANSWERS = {
    "why_interested": "\u2022\tOptimized network diagnostics by utilizing PuTTY and command-line tools to trace internal network routes, rapidly identifying and troubleshooting connectivity issues \u2013 reducing downtime and enhancing operational efficiency",
    "salary_expectation": "\u2022\tStreamlined operational workflows by coordinating cross-functional security initiatives, collaborating with infrastructure teams to implement firewall changes, conduct risk assessments, and enhance compliance strategies",
    "availability": "\u2022\tEnhanced threat detection capabilities by analyzing firewall logs with Excel  and Darktrace, identifying anomalies, and supporting users through real-time intervention both remotely and onsite"
}

# Browser Settings
BROWSER_SETTINGS = {
    "headless": False,  # Set to True to run browser in background
    "implicit_wait": 10,  # Seconds to wait for elements
    "page_load_timeout": 30  # Seconds to wait for page load
}
